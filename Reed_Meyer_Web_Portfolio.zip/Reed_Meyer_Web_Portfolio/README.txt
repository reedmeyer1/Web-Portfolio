Hi, My name is Reed Meyer and welcome to my web portfolio!
I am a Senior Information Technology major at the University of Missouri.

This project serves two main purposes.

	Purpose One: To display my ability with web development in a way that is tangible to potential employers

	Purpose Two: To extend my resume in a way that covers my other aptitudes.

There are a total of nine pages that make up this project, three of which are considered "main pages" with typical resume information.
The three main pages are as follows:

	index.html -- This page is where you should start. It is considered the "Home Page" of the site, it contains basic information, as well as links out to all other pages listed here.
	educationHistory.html -- This page is a non-comprehensive list of courses I have taken during my education, what skills they taught me, and what grade I ultimately received.
	programmingExperience.html -- This page is the dedicated launchoff point for the remain six project pages. (Web Dev Note: Due to the use of flexbox on this page in-particular, the number of projects that can be stored on this page is easily scalable.)

The remaining six pages are focused on six different projects I have worked on during my education at the University of Missouri.
Each project page will include both referential photos and descriptions that explain how each project works in detail.
The projects are as follows:

	FizzBuzz - written in Python - This project is notable as a popular IT interview topic, with the main purpose of displaying basic understand of programming
	TwitterClone - written in Python - This project emulates the twitter experience in a greatly simplified fashion. Users can choose four actions, Make a Tweet, View Recent Tweets, Search Tweets, and Quit the program.
	ObjectPositionCalculator - written in Python - This project calculates the position of an object over time and provides several examples of exception handling.
	URLEncoder - written in C# - This project queries the user for two inputs and generates a URL based on that information. The value of this project lies with the understanding of how URLs encode data within the ASCII character structure.
	PetsExample - written in C# - This project consists of three separate files that communicate with each other using class inheritance.
	TextFileGenerator - written in C# - This project generates simple custom text files by querying the user for name and contents of the file, attempting to write that file, and then notifying the user if is succeeds or fails.

-------------------------
HOW TO START THE PROJECT
-------------------------

	1) Navigate to the folder this file is stored in. This is the same folder you accessed to open the README.txt file in the first place.
	2) Find index.html in the file list, it may also appear as simply "index", and double click it.
	3) A window should appear in Chrome with the home page of the site.
	4) From here, all other facets of the site can be accessed from the home page, feel free to explore!

Thank you for considering me. If you wish to contact me for any reason, I can be reached by any means below, however email is preferred.

	Personal Email -- emailreedmeyer@gmail.com
	School Email -- rgmk7m@umsystem.edu
	Cell -- (630)-484-8605